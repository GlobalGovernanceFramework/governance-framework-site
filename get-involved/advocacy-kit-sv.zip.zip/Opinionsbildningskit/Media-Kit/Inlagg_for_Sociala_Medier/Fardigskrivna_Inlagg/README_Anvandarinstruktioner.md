# Hur du använder vårt material för sociala medier

Tack för att du hjälper oss att sprida ordet om Global Governance Frameworks-projektet!

Den här mappen innehåller färdiga inlägg som är organiserade efter tema. Använd dem gärna som de är, eller ännu hellre, anpassa dem med din egen röst och till din egen målgrupp.

**Några goda råd:**
* **Gör det personligt:** Lägg till dina egna tankar om varför du tycker att detta arbete är viktigt.
* **Tagga oss:** Tagga våra officiella konton så att vi kan se och dela dina inlägg!
* **Använd bilder:** Inkludera alltid en bild från vårt mediakit. Det ökar engagemanget markant.
* **Länka:** Inkludera alltid en länk till vår webbplats: `https://globalgovernanceframeworks.org`

Tack för att du är en ovärderlig del av denna rörelse.
