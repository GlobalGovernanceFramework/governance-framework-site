# How to Use the Social Media Pack

Thank you for helping us spread the word about the Global Governance Frameworks project!

This folder contains pre-written posts organized by theme. Please feel free to use them as they are, or even better, adapt them to your own voice and audience.

**Best Practices:**
* **Personalize:** Add your own thoughts on why this work matters.
* **Tag Us:** Tag our official accounts so we can see and share your posts!
* **Use Visuals:** Always include a visual from the Media Kit with your post. It dramatically increases engagement.
* **Link:** Always include a link to our website: `https://globalgovernanceframeworks.org`

Thank you for being a vital part of this movement.
